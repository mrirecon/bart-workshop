import struct as st
import numpy as np
import gzip
import sys
import os

sys.path.append(os.environ['TOOLBOX_PATH'] + "/python/")
import cfl

data_path_in=os.path.dirname(sys.argv[0])+"data/"
data_path_out=os.path.dirname(sys.argv[0])+"data/"

if not os.path.exists(data_path_out):
	os.makedirs(data_path_out)

# %%
"""
files = {   "train_images": "http://yann.lecun.com/exdb/mnist/train-images-idx3-ubyte.gz",
            "train_labels": "http://yann.lecun.com/exdb/mnist/train-labels-idx1-ubyte.gz",
            "test_images":  "http://yann.lecun.com/exdb/mnist/t10k-images-idx3-ubyte.gz",
            "test_labels":  "http://yann.lecun.com/exdb/mnist/t10k-labels-idx1-ubyte.gz"}

import urllib.request
for name in list(files):
    urllib.request.urlretrieve(files[name], data_path + name + '.gz')
"""

def convert_images(file_in, file_out):

	imagesfile = gzip.open(file_in,'rb')
	imagesfile.seek(0)
	magic = st.unpack('>4B',imagesfile.read(4))
	nImg = st.unpack('>I',imagesfile.read(4))[0] #num of images
	nR = st.unpack('>I',imagesfile.read(4))[0] #num of rows
	nC = st.unpack('>I',imagesfile.read(4))[0] #num of column
	images_array = np.zeros((nImg,nR,nC))
	nBytesTotal = nImg*nR*nC*1 #since each pixel data is 1 byte
	images = np.asarray(st.unpack('>'+'B'*nBytesTotal,imagesfile.read(nBytesTotal))).reshape((nImg,nR,nC))

	cfl.writecfl(file_out, np.transpose(images, (1,2,0)).astype(complex) / 255.)

def convert_labels(file_in, file_out):

	labelsfile = gzip.open(file_in,'rb')
	labelsfile.seek(0)
	magic = st.unpack('>4B',labelsfile.read(4))
	nImg = st.unpack('>I',labelsfile.read(4))[0] #num of images
	images_array = np.zeros((nImg))
	nBytesTotal = nImg*1 #since each pixel data is 1 byte
	labels = np.asarray(st.unpack('>'+'B'*nBytesTotal,labelsfile.read(nBytesTotal))).reshape((nImg))

	def hotenc(x):
		result = np.zeros((10, len(x)))
		for i in range(len(x)):
			result[x[i], i] = 1
		return result

	cfl.writecfl(file_out, hotenc(labels))

convert_images(data_path_in + 'train_images.gz', data_path_out + "train_images")
convert_images(data_path_in + 'test_images.gz', data_path_out + "test_images")

convert_labels(data_path_in + 'train_labels.gz', data_path_out + "train_labels")
convert_labels(data_path_in + 'test_labels.gz', data_path_out + "test_labels")